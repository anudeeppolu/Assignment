import logo from './logo.svg';
import './App.css';
import Header from './components/Header';
import Page from './components/Page';
import UserDisplay from './components/UserDisplay';

function App() {
  return (
    <div className="App">
    {/* <Header/> */}
    <UserDisplay/>
    </div>
  );
}

export default App;
