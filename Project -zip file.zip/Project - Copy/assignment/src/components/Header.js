import React from 'react';
import  centimelogo from "../Images/centimelogo.png"
const Header = () => {
  return (
    <header>
      <img src={centimelogo} alt="Centime Logo" />
    </header>
  );
};

export default Header;
